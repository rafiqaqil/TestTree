<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Laravel Users app.blade.php language lines
    |--------------------------------------------------------------------------
    */

    'nav' => [
        'toggle-nav-alt'    => 'Navigatie Aan/Uit',
        'login'             => 'Inloggen',
        'register'          => 'Registreren',
        'users'             => 'Gebruikers',
        'logout'            => 'Uitloggen',
    ],

];
