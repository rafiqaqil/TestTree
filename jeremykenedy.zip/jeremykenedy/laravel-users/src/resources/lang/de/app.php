<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Laravel Users app.blade.php language lines
    |--------------------------------------------------------------------------
    */

    'nav' => [
        'toggle-nav-alt'    => 'Navigation anzeigen/ausblenden',
        'login'             => 'Login',
        'register'          => 'Registrieren',
        'users'             => 'Benutzer',
        'logout'            => 'Logout',
    ],

];
