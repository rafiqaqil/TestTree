<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Laravel Users app.blade.php language lines
    |--------------------------------------------------------------------------
    */

    'nav' => [
        'toggle-nav-alt'    => 'Alterar Navegação',
        'login'             => 'Login',
        'register'          => 'Registrar',
        'users'             => 'Usuários',
        'logout'            => 'Sair',
    ],

];
